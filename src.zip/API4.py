# api
# endpoints principales:
# / transactions, clients, dashboard/kpis, dashboard/alerts, dashboard/financial
# /transaction/score (post para evaluacion en tiempo real)

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import pandas as pd
import numpy as np
import pickle
import os

# rutas de archivos
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
SCORED_CSV = os.path.join(DATA_DIR, "transactions_scored.csv")
CLIENTS_CSV = os.path.join(DATA_DIR, "clientes.csv")
MODEL_PKL = os.path.join(DATA_DIR, "model_best.pkl")
FINANCIAL_CSV = os.path.join(DATA_DIR, "financial_summary.csv")

PAISES_RIESGOSOS = {
    "KY","PA","VG","BZ","LB","IR","KP","MM","SY","YE","AF","HT","LA","UZ","VU","ZW"
}

# inicializacion api
app = FastAPI(title="AML Detection API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# carga de recursos
df_tx = pd.read_csv(SCORED_CSV, parse_dates=["fecha"])
df_clients = pd.read_csv(CLIENTS_CSV)

with open(MODEL_PKL, "rb") as f:
    model_bundle = pickle.load(f)

MODEL = model_bundle["modelo"]
FEATURES = model_bundle["features"]
THRESHOLD = model_bundle["threshold"]
METRICAS = model_bundle["metricas"]

# esquemas de datos
class NuevaTx(BaseModel):
    cliente_id: str
    monto: float
    tipo_tx: str
    pais_origen: str
    pais_destino: str
    canal: str
    hora: int

# utilitarios de formato
def tx_to_dict(row) -> dict:
    return {
        "transaction_id": row["transaction_id"],
        "cliente_id": row["cliente_id"],
        "fecha": str(row["fecha"]),
        "monto": round(float(row["monto"]), 2),
        "tipo_tx": row["tipo_tx"],
        "pais_origen": row["pais_origen"],
        "pais_destino": row["pais_destino"],
        "canal": row["canal"],
        "prob_fraude_ml": round(float(row["prob_fraude_ml"]), 4),
        "risk_score_final": round(float(row["risk_score_final"]), 4),
        "nivel_riesgo": str(row["nivel_riesgo_final"]),
        "alerta_activa": bool(row["alerta_activa"]),
        "fraude": bool(row["fraude"]),
        "patron_fraude": None if pd.isna(row["patron_fraude"]) else row["patron_fraude"],
        "flags": {
            "monto_inusual": bool(row["flag_monto_inusual"]),
            "frecuencia_anormal": bool(row["flag_frecuencia_anormal"]),
            "pais_riesgoso": bool(row["flag_pais_riesgoso"]),
            "smurfing": bool(row["flag_smurfing"]),
        }
    }

def client_profile(cliente_id: str) -> dict:
    cli = df_clients[df_clients["cliente_id"] == cliente_id]
    if cli.empty: return {}
    row = cli.iloc[0]
    txs = df_tx[df_tx["cliente_id"] == cliente_id]
    max_score = float(txs["risk_score_final"].max()) if len(txs) > 0 else 0.0
    return {
        "cliente_id": row["cliente_id"],
        "nombre": row["nombre"],
        "pais_habitual": row["pais_habitual"],
        "antiguedad_dias": int(row["antiguedad_dias"]),
        "promedio_gasto": round(float(row["promedio_gasto"]), 2),
        "segmento": row["segmento"],
        "total_tx": len(txs),
        "total_fraudes": int(txs["fraude"].sum()),
        "max_risk_score": round(max_score, 4),
        "nivel_riesgo": "ALTO" if max_score >= 0.7 else ("MEDIO" if max_score >= 0.3 else "BAJO"),
    }

# endpoints de consulta
@app.get("/")
def health():
    return {"status": "ok", "total_tx": len(df_tx), "metricas": METRICAS}

@app.get("/transactions")
def get_transactions(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    nivel_riesgo: Optional[str] = Query(None),
    solo_alertas: bool = Query(False),
    cliente_id: Optional[str] = Query(None),
    canal: Optional[str] = Query(None),
    orden: str = Query("risk_score_final")
):
    df = df_tx.copy()
    if nivel_riesgo: df = df[df["nivel_riesgo_final"] == nivel_riesgo.upper()]
    if solo_alertas: df = df[df["alerta_activa"] == 1]
    if cliente_id: df = df[df["cliente_id"] == cliente_id]
    if canal: df = df[df["canal"] == canal.lower()]

    df = df.sort_values(orden, ascending=False)
    total = len(df)
    start = (page - 1) * page_size
    return {
        "total": total,
        "page": page,
        "data": [tx_to_dict(row) for _, row in df.iloc[start:start+page_size].iterrows()]
    }

@app.get("/transactions/{tx_id}")
def get_transaction(tx_id: str):
    row = df_tx[df_tx["transaction_id"] == tx_id]
    if row.empty: raise HTTPException(status_code=404, detail="no encontrado")
    return tx_to_dict(row.iloc[0])

@app.get("/clients/{client_id}")
def get_client(client_id: str):
    perfil = client_profile(client_id)
    if not perfil: raise HTTPException(status_code=404, detail="cliente no existe")
    txs = df_tx[df_tx["cliente_id"] == client_id].sort_values("fecha", ascending=False)
    perfil["transacciones"] = [tx_to_dict(row) for _, row in txs.head(50).iterrows()]
    return perfil

# motor de scoring
@app.post("/transaction/score")
def score_transaction(tx: NuevaTx):
    historial = df_tx[df_tx["cliente_id"] == tx.cliente_id]["monto"]
    cli_data = df_clients[df_clients["cliente_id"] == tx.cliente_id]

    if cli_data.empty:
        promedio, desviacion, antiguedad = tx.monto, tx.monto * 0.3, 0
    else:
        cli = cli_data.iloc[0]
        promedio = float(historial.mean()) if len(historial) >= 3 else float(cli["promedio_gasto"])
        desviacion = float(historial.std()) if len(historial) >= 3 else promedio * 0.3
        antiguedad = int(cli["antiguedad_dias"])

    feats = {
        "monto_vs_promedio": tx.monto / promedio if promedio > 0 else 1.0,
        "frecuencia_tx_1h": 0,
        "frecuencia_tx_24h": 0,
        "score_smurfing": 0.5 if (500 <= tx.monto <= 3000) else 0.0,
        "pais_riesgoso": int(tx.pais_destino in PAISES_RIESGOSOS),
        "cambio_ubicacion": int(tx.pais_destino != tx.pais_origen),
        "cliente_nuevo": int(antiguedad < 90),
        "hora_inusual": int(0 <= tx.hora <= 4),
        "desviacion_gasto": max(desviacion, 1.0),
    }

    X_new = pd.DataFrame([feats])[FEATURES]
    prob = float(MODEL.predict_proba(X_new)[0][1])
    
    flags = {
        "monto_inusual": feats["monto_vs_promedio"] > 3,
        "pais_riesgoso": bool(feats["pais_riesgoso"]),
        "posible_smurfing": feats["score_smurfing"] > 0
    }

    nivel = "ALTO" if prob >= 0.7 else ("MEDIO" if prob >= 0.3 else "BAJO")
    return {
        "prob_fraude_ml": round(prob, 4),
        "nivel_riesgo": nivel,
        "alerta_activa": prob >= THRESHOLD or any(flags.values()),
        "flags": flags
    }

# reportes dashboard
@app.get("/dashboard/kpis")
def get_kpis():
    total = len(df_tx)
    fraudes = int(df_tx["fraude"].sum())
    alertas = int(df_tx["alerta_activa"].sum())
    return {
        "total_transacciones": total,
        "fraudes_reales": fraudes,
        "alertas_activas": alertas,
        "monto_en_riesgo": round(float(df_tx[df_tx["fraude"]==1]["monto"].sum()), 2)
    }

@app.get("/dashboard/financial")
def get_financial_summary():
    if not os.path.exists(FINANCIAL_CSV):
        raise HTTPException(status_code=404, detail="resumen financiero no generado")
    df_fin = pd.read_csv(FINANCIAL_CSV)
    return df_fin.to_dict(orient="records")[0]