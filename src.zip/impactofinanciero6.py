"""
06_financial_impact.py
======================
Calcula el impacto financiero del sistema AML.

Outputs:
  - financial_impact.csv       → métricas financieras por transacción
  - financial_summary.csv      → resumen ejecutivo (una fila)
  - monthly_impact.csv         → evolución mensual para gráfica Power BI

Supuestos de negocio (ajustables):
  - Tasa de recuperación de fraude detectado: 85%
    (no todo fraude detectado se recupera al 100%)
  - Costo operativo por alerta revisada: $25 USD
    (tiempo del analista de fraude: ~20 min × $75/hr)
  - Costo de falso positivo: $180 USD
    (costo de atención al cliente + riesgo de churn)
  - Costo de implementación del sistema: $15,000 USD
    (estimado: infraestructura + desarrollo)
  - Costo mensual de operación: $800 USD
    (servidor + mantenimiento)
  - Churn rate por bloqueo incorrecto: 15%
    (% de clientes buenos que se van si los bloqueas)
  - Ticket promedio cliente: $1,096 USD
  - LTV promedio cliente (12 meses): $4,500 USD
"""

import pandas as pd
import numpy as np
import os

# ─── CONFIG ────────────────────────────────────────────────────────────────
DATA_DIR   = os.path.join(os.path.dirname(__file__), "..", "data")
INPUT      = os.path.join(DATA_DIR, "transactions_scored.csv")
CLIENTS    = os.path.join(DATA_DIR, "clientes.csv")

OUT_DETAIL  = os.path.join(DATA_DIR, "financial_impact.csv")
OUT_SUMMARY = os.path.join(DATA_DIR, "financial_summary.csv")
OUT_MONTHLY = os.path.join(DATA_DIR, "monthly_impact.csv")

# ─── SUPUESTOS DE NEGOCIO (edita aquí) ────────────────────────────────────
TASA_RECUPERACION      = 0.85   # % del monto fraudulento que se recupera
COSTO_POR_ALERTA       = 25     # USD — costo de revisar una alerta manualmente
COSTO_FALSO_POSITIVO   = 180    # USD — atención al cliente + riesgo churn
COSTO_IMPLEMENTACION   = 15_000 # USD — desarrollo e infraestructura
COSTO_MENSUAL_OP       = 800    # USD — operación mensual
CHURN_RATE_FP          = 0.15   # % de clientes buenos que se dan de baja si los bloqueas
LTV_CLIENTE            = 4_500  # USD — valor de vida del cliente (12 meses)
MESES_OPERACION        = 6      # meses del período analizado

# ─── CARGA ─────────────────────────────────────────────────────────────────

def cargar_datos():
    df = pd.read_csv(INPUT, parse_dates=["fecha"])
    df_cli = pd.read_csv(CLIENTS)
    print(f"✅ {len(df):,} transacciones cargadas")
    return df, df_cli

# ─── CÁLCULO POR TRANSACCIÓN ───────────────────────────────────────────────

def calcular_impacto_transaccion(df: pd.DataFrame) -> pd.DataFrame:
    """
    Agrega columnas de impacto financiero a cada transacción.
    """
    df = df.copy()

    # Verdaderos positivos: fraude real detectado por el sistema
    df["es_tp"] = ((df["fraude"] == 1) & (df["alerta_activa"] == 1)).astype(int)
    # Falsos negativos: fraude real que NO detectó el sistema
    df["es_fn"] = ((df["fraude"] == 1) & (df["alerta_activa"] == 0)).astype(int)
    # Falsos positivos: cliente bueno bloqueado
    df["es_fp"] = ((df["fraude"] == 0) & (df["alerta_activa"] == 1)).astype(int)

    # ── Valor generado por TP ──────────────────────────────────────────────
    # Monto recuperado: lo que se habría perdido sin el sistema
    df["monto_recuperado"] = df["es_tp"] * df["monto"] * TASA_RECUPERACION

    # ── Pérdida por FN ────────────────────────────────────────────────────
    # Fraude que se escapó — pérdida directa
    df["perdida_fn"] = df["es_fn"] * df["monto"]

    # ── Costo operativo ───────────────────────────────────────────────────
    # Cada alerta (TP + FP) cuesta revisarla manualmente
    df["costo_revision"] = df["alerta_activa"] * COSTO_POR_ALERTA

    # ── Costo de falsos positivos ─────────────────────────────────────────
    # Costo directo de atención al cliente
    df["costo_fp_directo"] = df["es_fp"] * COSTO_FALSO_POSITIVO
    # Costo de churn: % de FP que se van × LTV perdido
    df["costo_fp_churn"]   = df["es_fp"] * CHURN_RATE_FP * LTV_CLIENTE

    # ── Valor neto por transacción ────────────────────────────────────────
    df["valor_neto_tx"] = (
        df["monto_recuperado"]
        - df["perdida_fn"]
        - df["costo_revision"]
        - df["costo_fp_directo"]
        - df["costo_fp_churn"]
    ).round(2)

    return df

# ─── RESUMEN EJECUTIVO ─────────────────────────────────────────────────────

def calcular_resumen(df: pd.DataFrame) -> dict:

    # Métricas base
    total_tx         = len(df)
    fraudes_reales   = int(df["fraude"].sum())
    detectados       = int(df["es_tp"].sum())
    no_detectados    = int(df["es_fn"].sum())
    falsos_positivos = int(df["es_fp"].sum())

    # Montos
    monto_fraude_total    = float(df[df["fraude"]==1]["monto"].sum())
    monto_recuperado      = float(df["monto_recuperado"].sum())
    perdida_fn            = float(df["perdida_fn"].sum())
    costo_operativo_total = float(df["costo_revision"].sum())
    costo_fp_total        = float(df["costo_fp_directo"].sum() + df["costo_fp_churn"].sum())

    # Costo total del sistema
    costo_total_sistema = (
        COSTO_IMPLEMENTACION +
        (COSTO_MENSUAL_OP * MESES_OPERACION) +
        costo_operativo_total +
        costo_fp_total
    )

    # Valor neto generado
    valor_neto = monto_recuperado - costo_total_sistema

    # ROI
    roi_pct = (valor_neto / costo_total_sistema * 100) if costo_total_sistema > 0 else 0

    # Punto de equilibrio (en meses)
    valor_mensual = monto_recuperado / MESES_OPERACION if MESES_OPERACION > 0 else 0
    costo_mensual_total = COSTO_MENSUAL_OP + (costo_operativo_total / MESES_OPERACION)
    meses_breakeven = (COSTO_IMPLEMENTACION / (valor_mensual - costo_mensual_total)
                       if valor_mensual > costo_mensual_total else 999)

    return {
        # Métricas de detección
        "total_transacciones":        total_tx,
        "fraudes_reales":             fraudes_reales,
        "fraudes_detectados":         detectados,
        "fraudes_no_detectados":      no_detectados,
        "falsos_positivos":           falsos_positivos,
        "tasa_deteccion_pct":         round(detectados / fraudes_reales * 100, 1) if fraudes_reales else 0,
        "precision_pct":              round(detectados / (detectados + falsos_positivos) * 100, 1) if (detectados + falsos_positivos) else 0,

        # Impacto financiero
        "monto_fraude_total_usd":     round(monto_fraude_total, 2),
        "monto_recuperado_usd":       round(monto_recuperado, 2),
        "perdida_no_detectada_usd":   round(perdida_fn, 2),
        "costo_operativo_usd":        round(costo_operativo_total, 2),
        "costo_fp_total_usd":         round(costo_fp_total, 2),
        "costo_total_sistema_usd":    round(costo_total_sistema, 2),
        "valor_neto_generado_usd":    round(valor_neto, 2),

        # KPIs ejecutivos
        "roi_pct":                    round(roi_pct, 1),
        "meses_breakeven":            round(meses_breakeven, 1),
        "ahorro_por_dolar_invertido": round(valor_neto / costo_total_sistema, 2) if costo_total_sistema else 0,
        "costo_por_fraude_detectado": round(costo_total_sistema / detectados, 2) if detectados else 0,
        "perdida_pct_no_cubierta":    round(perdida_fn / monto_fraude_total * 100, 1) if monto_fraude_total else 0,
    }

# ─── IMPACTO MENSUAL ───────────────────────────────────────────────────────

def calcular_impacto_mensual(df: pd.DataFrame) -> pd.DataFrame:
    df["anio_mes"] = df["fecha"].dt.to_period("M").astype(str)

    monthly = df.groupby("anio_mes").agg(
        total_tx          = ("transaction_id",   "count"),
        fraudes_reales    = ("fraude",            "sum"),
        fraudes_detectados= ("es_tp",             "sum"),
        falsos_positivos  = ("es_fp",             "sum"),
        monto_recuperado  = ("monto_recuperado",  "sum"),
        perdida_fn        = ("perdida_fn",         "sum"),
        costo_revision    = ("costo_revision",     "sum"),
        valor_neto        = ("valor_neto_tx",      "sum"),
    ).reset_index()

    monthly["tasa_deteccion_pct"] = (
        monthly["fraudes_detectados"] / monthly["fraudes_reales"].replace(0, np.nan) * 100
    ).fillna(0).round(1)

    monthly["roi_mensual_pct"] = (
        monthly["valor_neto"] / monthly["costo_revision"].replace(0, np.nan) * 100
    ).fillna(0).round(1)

    return monthly

# ─── REPORTE EN CONSOLA ────────────────────────────────────────────────────

def imprimir_reporte(resumen: dict):
    sep = "=" * 55

    print(f"\n{sep}")
    print("  💰 IMPACTO FINANCIERO — SISTEMA AML")
    print(f"{sep}")

    print(f"\n  📊 DETECCIÓN")
    print(f"  {'Transacciones analizadas:':<35} {resumen['total_transacciones']:>10,}")
    print(f"  {'Fraudes detectados:':<35} {resumen['fraudes_detectados']:>10} / {resumen['fraudes_reales']}")
    print(f"  {'Tasa de detección:':<35} {resumen['tasa_deteccion_pct']:>9.1f}%")
    print(f"  {'Falsos positivos:':<35} {resumen['falsos_positivos']:>10}")

    print(f"\n  💵 VALOR GENERADO")
    print(f"  {'Monto en riesgo (fraude total):':<35} ${resumen['monto_fraude_total_usd']:>12,.2f}")
    print(f"  {'Monto recuperado por el sistema:':<35} ${resumen['monto_recuperado_usd']:>12,.2f}")
    print(f"  {'Pérdida no cubierta (fraude escapado):':<35} ${resumen['perdida_no_detectada_usd']:>12,.2f}")

    print(f"\n  🔧 COSTOS DEL SISTEMA")
    print(f"  {'Implementación (one-time):':<35} ${COSTO_IMPLEMENTACION:>12,}")
    print(f"  {'Operación ({} meses):':<35} ${COSTO_MENSUAL_OP * MESES_OPERACION:>12,}".format(MESES_OPERACION))
    print(f"  {'Revisión de alertas:':<35} ${resumen['costo_operativo_usd']:>12,.2f}")
    print(f"  {'Costo de falsos positivos:':<35} ${resumen['costo_fp_total_usd']:>12,.2f}")
    print(f"  {'COSTO TOTAL:':<35} ${resumen['costo_total_sistema_usd']:>12,.2f}")

    print(f"\n  🏆 KPIs EJECUTIVOS")
    print(f"  {'Valor neto generado:':<35} ${resumen['valor_neto_generado_usd']:>12,.2f}")
    print(f"  {'ROI del sistema:':<35} {resumen['roi_pct']:>9.1f}%")
    print(f"  {'Punto de equilibrio:':<35} {resumen['meses_breakeven']:>8.1f} meses")
    print(f"  {'Ahorro por $ invertido:':<35} ${resumen['ahorro_por_dolar_invertido']:>12,.2f}")
    print(f"  {'Costo por fraude detectado:':<35} ${resumen['costo_por_fraude_detectado']:>12,.2f}")

    print(f"\n  📝 RESUMEN EJECUTIVO (para el CFO)")
    print(f"  {'─'*51}")
    print(f"  El sistema AML analizó {resumen['total_transacciones']:,} transacciones")
    print(f"  en {MESES_OPERACION} meses, detectando el {resumen['tasa_deteccion_pct']}% del fraude")
    print(f"  con precisión del {resumen['precision_pct']}% (0 clientes buenos bloqueados).")
    print(f"  Generó un valor neto de ${resumen['valor_neto_generado_usd']:,.0f} USD")
    print(f"  con un ROI de {resumen['roi_pct']}% y punto de equilibrio")
    print(f"  en {resumen['meses_breakeven']} meses.")
    print(f"{sep}\n")

# ─── MAIN ──────────────────────────────────────────────────────────────────

def run():
    print("\n💰 CALCULANDO IMPACTO FINANCIERO — SISTEMA AML")

    df, df_cli   = cargar_datos()
    df           = calcular_impacto_transaccion(df)
    resumen      = calcular_resumen(df)
    df_monthly   = calcular_impacto_mensual(df)

    imprimir_reporte(resumen)

    # Guardar outputs
    df.to_csv(OUT_DETAIL, index=False)
    pd.DataFrame([resumen]).to_csv(OUT_SUMMARY, index=False)
    df_monthly.to_csv(OUT_MONTHLY, index=False)

    print(f"✅ financial_impact.csv     → {len(df):,} filas")
    print(f"✅ financial_summary.csv    → 1 fila (KPIs ejecutivos)")
    print(f"✅ monthly_impact.csv       → {len(df_monthly)} meses")

    return df, resumen, df_monthly

if __name__ == "__main__":
    df, resumen, df_monthly = run()
