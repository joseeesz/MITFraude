import subprocess
import os
import sys

# nota: obtiene la ruta absoluta de la carpeta donde esta este script
ruta_scripts = os.path.dirname(os.path.abspath(__file__))

def ejecutar(archivo):
    # nota: une la carpeta con el nombre del archivo
    ruta_completa = os.path.join(ruta_scripts, archivo)
    print(f"ejecutando {archivo}")
    res = subprocess.run([sys.executable, ruta_completa])
    if res.returncode != 0:
        # nota: termina si falla un paso
        sys.exit(1)

if __name__ == "__main__":
    # nota: lista de archivos en orden
    pasos = [
        "generadordata1.py",
        "atributosfe2.py",
        "modelo3.py",
        "impactofinanciero6.py"
    ]

    for p in pasos:
        # nota: valida existencia en la ruta automatica
        if os.path.exists(os.path.join(ruta_scripts, p)):
            ejecutar(p)
        else:
            # nota: error de archivo faltante
            print(f"error no se encontro {p} en {ruta_scripts}")
            sys.exit(1)

    print("proceso terminado")