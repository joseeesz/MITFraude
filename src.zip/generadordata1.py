# generador
# genera dataset aml con clientes base y casos de fraude inyectados
# patrones: monto inusual, frecuencia anormal, ubicacion inconsistente, smurfing

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import random
import os

# configuracion
SEED = 42
np.random.seed(SEED)
random.seed(SEED)

N_CLIENTES_BASE = 220
START_DATE = datetime(2024, 1, 1)
END_DATE = datetime(2024, 6, 30)
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)

PAISES_NORMALES = ["MX", "MX", "MX", "US", "CA", "ES", "CO"]
PAISES_RIESGOSOS = ["KY", "PA", "VG", "BZ", "LB", "IR", "KP"]
CANALES = ["app", "web", "sucursal", "api"]
TIPOS_TX = ["compra", "transferencia", "retiro", "deposito"]

# lista simplificada para evitar ruido
NOMBRES = [
    "Alejandro Vega", "Maria Torres", "Carlos Ruiz", "Ana Lopez", "Luis Martinez",
    "Sofia Garcia", "Jorge Hernandez", "Valentina Cruz", "Miguel Flores", "Isabella Diaz",
    "Roberto Sanchez", "Camila Moreno", "Daniel Jimenez", "Gabriela Reyes", "Eduardo Castro"
] * 20 

def random_date(start, end):
    delta = end - start
    return start + timedelta(seconds=random.randint(0, int(delta.total_seconds())))

def generar_cliente_base(cid, nombre):
    return {
        "cliente_id": cid,
        "nombre": nombre,
        "pais_habitual": random.choice(PAISES_NORMALES),
        "antiguedad_dias": random.randint(90, 2000),
        "promedio_gasto": round(random.uniform(200, 2000), 2),
        "segmento": random.choice(["retail", "pyme", "corporativo"]),
        "saldo_promedio": round(random.uniform(1000, 50000), 2),
    }

def generar_tx_normales(cliente, n):
    txs = []
    for _ in range(n):
        monto = max(10.0, round(abs(np.random.normal(cliente["promedio_gasto"], cliente["promedio_gasto"] * 0.3)), 2))
        txs.append({
            "tipo_tx": random.choice(TIPOS_TX),
            "monto": monto,
            "fecha": random_date(START_DATE, END_DATE),
            "pais_origen": cliente["pais_habitual"],
            "pais_destino": cliente["pais_habitual"],
            "canal": random.choice(CANALES),
            "saldo_post": round(cliente["saldo_promedio"] + random.uniform(-500, 500), 2),
            "fraude": 0,
            "patron_fraude": None,
        })
    return txs

# funciones de patrones de fraude
def patron_monto_inusual(cliente):
    txs = generar_tx_normales(cliente, 30)
    for _ in range(5):
        monto = round(cliente["promedio_gasto"] * random.uniform(10, 20), 2)
        txs.append({
            "tipo_tx": "transferencia", "monto": monto, "fecha": random_date(datetime(2024, 5, 1), END_DATE),
            "pais_origen": cliente["pais_habitual"], "pais_destino": cliente["pais_habitual"],
            "canal": "web", "saldo_post": round(cliente["saldo_promedio"] - monto, 2),
            "fraude": 1, "patron_fraude": "MONTO_INUSUAL"
        })
    return txs

def patron_frecuencia_anormal(cliente):
    txs = generar_tx_normales(cliente, 25)
    base_time = datetime(2024, 4, 15, 2, 0, 0)
    for i in range(8):
        monto = round(random.uniform(800, 2500), 2)
        txs.append({
            "tipo_tx": "retiro", "monto": monto, "fecha": base_time + timedelta(minutes=random.randint(0, 45)),
            "pais_origen": cliente["pais_habitual"], "pais_destino": cliente["pais_habitual"],
            "canal": "app", "saldo_post": round(cliente["saldo_promedio"] - monto * i, 2),
            "fraude": 1, "patron_fraude": "FRECUENCIA_ANORMAL"
        })
    return txs

def patron_ubicacion_inconsistente(cliente):
    txs = generar_tx_normales(cliente, 40)
    for pais in random.sample(PAISES_RIESGOSOS, 4):
        monto = round(random.uniform(5000, 25000), 2)
        txs.append({
            "tipo_tx": "transferencia", "monto": monto, "fecha": random_date(datetime(2024, 3, 1), END_DATE),
            "pais_origen": cliente["pais_habitual"], "pais_destino": pais,
            "canal": "api", "saldo_post": round(cliente["saldo_promedio"] - monto, 2),
            "fraude": 1, "patron_fraude": "UBICACION_INCONSISTENTE"
        })
    return txs

def patron_smurfing(cliente):
    txs = generar_tx_normales(cliente, 20)
    base_time = datetime(2024, 5, 20, 14, 0, 0)
    for i in range(12):
        monto = round(random.uniform(900, 1100), 2)
        txs.append({
            "tipo_tx": "deposito", "monto": monto, "fecha": base_time + timedelta(minutes=random.randint(0, 90)),
            "pais_origen": cliente["pais_habitual"], "pais_destino": cliente["pais_habitual"],
            "canal": "app", "saldo_post": round(cliente["saldo_promedio"] + monto * i, 2),
            "fraude": 1, "patron_fraude": "SMURFING"
        })
    return txs

def generar_dataset():
    clientes, transacciones = [], []
    tx_id = 1

    # clientes normales
    for i in range(N_CLIENTES_BASE):
        cid = f"C{str(i+1).zfill(4)}"
        cliente = generar_cliente_base(cid, NOMBRES[i])
        clientes.append(cliente)
        for tx in generar_tx_normales(cliente, random.randint(8, 25)):
            tx.update({"transaction_id": f"TX{str(tx_id).zfill(6)}", "cliente_id": cid})
            transacciones.append(tx)
            tx_id += 1

    # inyeccion de fraudes
    fraudes_cfg = [
        ("CFRD01", "Vladimir Petrov", patron_monto_inusual, 450, 730),
        ("CFRD02", "Zhang Wei", patron_frecuencia_anormal, 380, 180),
        ("CFRD03", "Dimitri Volkov", patron_ubicacion_inconsistente, 1200, 1100),
        ("CFRD04", "Mohammed Al-Rashid", patron_smurfing, 600, 95),
    ]

    for cid, nombre, fn, avg, ant in fraudes_cfg:
        cliente = generar_cliente_base(cid, nombre)
        cliente.update({"promedio_gasto": avg, "antiguedad_dias": ant, "pais_habitual": "MX"})
        clientes.append(cliente)
        for tx in fn(cliente):
            tx.update({"transaction_id": f"TX{str(tx_id).zfill(6)}", "cliente_id": cid})
            transacciones.append(tx)
            tx_id += 1

    df_cli = pd.DataFrame(clientes)
    df_txs = pd.DataFrame(transacciones).sort_values("fecha").reset_index(drop=True)
    
    df_cli.to_csv(os.path.join(OUTPUT_DIR, "clientes.csv"), index=False)
    df_txs.to_csv(os.path.join(OUTPUT_DIR, "transactions.csv"), index=False)
    
    print(f"archivos guardados en {OUTPUT_DIR}")
    return df_cli, df_txs

if __name__ == "__main__":
    generar_dataset()