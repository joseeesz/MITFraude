# modelo
# pipeline ml para deteccion de fraude aml
# compara logistic regression, random forest y gradient boosting

import pandas as pd
import numpy as np
import pickle
import os
import warnings
warnings.filterwarnings("ignore")

from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.linear_model    import LogisticRegression
from sklearn.ensemble        import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing   import StandardScaler
from sklearn.pipeline        import Pipeline
from sklearn.metrics         import (
    classification_report, roc_auc_score, average_precision_score,
    confusion_matrix, precision_recall_curve
)
from sklearn.utils           import resample

# config
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
INPUT = os.path.join(DATA_DIR, "transactions_features.csv")
OUTPUT_MODEL = os.path.join(DATA_DIR, "model_best.pkl")
OUTPUT_SCORED = os.path.join(DATA_DIR, "transactions_scored.csv")

FEATURES = [
    "monto_vs_promedio", "frecuencia_tx_1h", "frecuencia_tx_24h",
    "score_smurfing", "pais_riesgoso", "cambio_ubicacion",
    "cliente_nuevo", "hora_inusual", "desviacion_gasto"
]

TARGET = "fraude"
SEED = 42

def cargar_datos():
    df = pd.read_csv(INPUT, parse_dates=["fecha"])
    return df

def balancear_clases(X, y):
    # oversampling minoritario con ratio 1:10
    df = X.copy()
    df[TARGET] = y.values
    mayoria = df[df[TARGET] == 0]
    minoria = df[df[TARGET] == 1]
    
    target_n = len(mayoria) // 10
    minoria_os = resample(minoria, replace=True, n_samples=max(target_n, len(minoria)), random_state=SEED)
    
    df_bal = pd.concat([mayoria, minoria_os])
    return df_bal[FEATURES], df_bal[TARGET]

def construir_modelos():
    return {
        "Logistic Regression": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(class_weight="balanced", max_iter=1000, C=0.1, random_state=SEED))
        ]),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, max_depth=8, class_weight="balanced", random_state=SEED, n_jobs=-1
        ),
        "Gradient Boosting": GradientBoostingClassifier(
            n_estimators=200, max_depth=4, learning_rate=0.05, subsample=0.8, random_state=SEED
        )
    }

def evaluar_modelo(nombre, modelo, X, y):
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    y_prob = cross_val_predict(modelo, X, y, cv=cv, method="predict_proba")[:, 1]

    # buscar threshold optimo segun f1
    prec, rec, threshs = precision_recall_curve(y, y_prob)
    f1s = 2 * prec * rec / (prec + rec + 1e-8)
    best_idx = np.argmax(f1s[:-1])
    best_t = threshs[best_idx]

    y_pred = (y_prob >= best_t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, y_pred).ravel()
    
    return {
        "nombre": nombre, 
        "threshold": round(best_t, 4),
        "precision": round(tp / (tp + fp) if (tp + fp) > 0 else 0, 4),
        "recall": round(tp / (tp + fn) if (tp + fn) > 0 else 0, 4),
        "f1": round(f1s[best_idx], 4),
        "auc_roc": round(roc_auc_score(y, y_prob), 4),
        "auc_pr": round(average_precision_score(y, y_prob), 4),
        "y_prob": y_prob,
        "modelo": modelo
    }

def generar_scores_finales(df, ganador):
    df_out = df.copy()
    
    # Probabilidad ML
    df_out["prob_fraude_ml"] = ganador["y_prob"].round(4)
    
    # Score hibrido: 40% reglas (risk_score original) + 60% ML
    df_out["risk_score_final"] = (
        df_out["risk_score"] * 0.40 + 
        df_out["prob_fraude_ml"] * 0.60
    ).round(4)
    
    # Clasificacion final
    df_out["nivel_riesgo_final"] = pd.cut(
        df_out["risk_score_final"],
        bins=[-0.001, 0.30, 0.70, 1.01],
        labels=["BAJO", "MEDIO", "ALTO"]
    )
    
    # Alerta activa si riesgo es ALTO o cualquier flag de reglas esta encendido
    df_out["alerta_activa"] = (
        (df_out["nivel_riesgo_final"] == "ALTO") | 
        (df_out["flag_monto_inusual"] == 1) | 
        (df_out["flag_frecuencia_anormal"] == 1) | 
        (df_out["flag_pais_riesgoso"] == 1) | 
        (df_out["flag_smurfing"] == 1)
    ).astype(int)
    
    df_out.to_csv(OUTPUT_SCORED, index=False)
    return df_out

if __name__ == "__main__":
    df = cargar_datos()
    X, y = df[FEATURES], df[TARGET]
    X_bal, y_bal = balancear_clases(X, y)
    
    modelos = construir_modelos()
    resultados = []
    
    print("Entrenando modelos...")
    for nombre, modelo in modelos.items():
        res = evaluar_modelo(nombre, modelo, X_bal, y_bal)
        resultados.append(res)
        print(f"-> {nombre}: F1={res['f1']} | AUC-ROC={res['auc_roc']}")
        
    # El ganador es el de mejor F1
    ganador = max(resultados, key=lambda x: x["f1"])
    print(f"\nGanador: {ganador['nombre']}")
    
    # Generar scores sobre el dataset original (sin oversampling)
    # Re-evaluamos con CV sobre datos reales para evitar sesgos
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    y_prob_real = cross_val_predict(ganador["modelo"], X, y, cv=cv, method="predict_proba")[:, 1]
    ganador["y_prob"] = y_prob_real
    
    df_final = generar_scores_finales(df, ganador)
    
    # Guardar modelo
    with open(OUTPUT_MODEL, "wb") as f:
        pickle.dump({
            "modelo": ganador["modelo"].fit(X_bal, y_bal),
            "nombre": ganador["nombre"],
            "features": FEATURES,
            "threshold": ganador["threshold"],
            "metricas": {
                "f1": ganador["f1"],
                "precision": ganador["precision"],
                "recall": ganador["recall"]
            }
        }, f)
    
    print(f"\nProceso terminado. Resultados guardados en: {OUTPUT_SCORED}")