# script powerbi
# cargar en power bi: obtener datos > script de python
# requiere: pip install pandas numpy

import pandas as pd
import numpy as np
from datetime import datetime

# ruta de archivos !!!!!!!!!!!! IMPORTANTE: CAMBIAR ESTA RUTA!!!!!!!!!!
BASE_PATH = r"C:\Users\josel\OneDrive\Escritorio\AML PP\data" 

# carga de transacciones y datos financieros detallados
df_tx = pd.read_csv(f"{BASE_PATH}\\transactions_scored.csv", parse_dates=["fecha"])
df_fin = pd.read_csv(f"{BASE_PATH}\\financial_impact.csv")

# tabla de hechos (incluye impacto financiero por operacion)
fact_transacciones = pd.DataFrame({
    "transaction_id":       df_tx["transaction_id"],
    "cliente_id":           df_tx["cliente_id"],
    "fecha":                df_tx["fecha"],
    "fecha_date":           df_tx["fecha"].dt.date,
    "anio":                 df_tx["fecha"].dt.year,
    "mes":                  df_tx["fecha"].dt.month,
    "mes_nombre":           df_tx["fecha"].dt.strftime("%B"),
    "semana":               df_tx["fecha"].dt.isocalendar().week.astype(int),
    "dia_semana":           df_tx["fecha"].dt.day_name(),
    "hora":                 df_tx["fecha"].dt.hour,
    "monto":                df_tx["monto"].round(2),
    "tipo_tx":              df_tx["tipo_tx"],
    "pais_origen":          df_tx["pais_origen"],
    "pais_destino":         df_tx["pais_destino"],
    "canal":                df_tx["canal"],
    "monto_vs_promedio":    df_tx["monto_vs_promedio"].round(4),
    "frecuencia_tx_1h":     df_tx["frecuencia_tx_1h"],
    "score_smurfing":       df_tx["score_smurfing"].round(4),
    "prob_fraude_ml":       df_tx["prob_fraude_ml"].round(4),
    "risk_score_final":     df_tx["risk_score_final"].round(4),
    "nivel_riesgo":         df_tx["nivel_riesgo_final"],
    "alerta_activa":        df_tx["alerta_activa"].astype(int),
    "es_fraude":            df_tx["fraude"].astype(int),
    "patron_fraude":        df_tx["patron_fraude"].fillna("Legitima"),
    "flag_monto_inusual":   df_tx["flag_monto_inusual"].astype(int),
    "flag_frecuencia":      df_tx["flag_frecuencia_anormal"].astype(int),
    "flag_pais_riesgoso":   df_tx["flag_pais_riesgoso"].astype(int),
    "flag_smurfing":        df_tx["flag_smurfing"].astype(int)
})

# integrar columnas financieras a la tabla de hechos
fact_transacciones = fact_transacciones.merge(
    df_fin[["transaction_id", "monto_recuperado", "costo_revision", "costo_fp_directo", "costo_fp_churn", "valor_neto_tx"]], 
    on="transaction_id", 
    how="left"
)

# carga de clientes y metricas
df_cli = pd.read_csv(f"{BASE_PATH}\\clientes.csv")
agg = fact_transacciones.groupby("cliente_id").agg(
    total_transacciones = ("transaction_id", "count"),
    total_fraudes       = ("es_fraude",       "sum"),
    total_alertas       = ("alerta_activa",   "sum"),
    max_risk_score      = ("risk_score_final","max")
).reset_index()

dim_clientes = df_cli.merge(agg, on="cliente_id", how="left")

# tabla calendario
fechas = pd.date_range(
    start=fact_transacciones["fecha"].min().normalize(),
    end=fact_transacciones["fecha"].max().normalize(),
    freq="D"
)
dim_calendario = pd.DataFrame({
    "fecha":      fechas,
    "anio":       fechas.year,
    "mes_nombre": fechas.strftime("%B")
})

# resumen de kpis ejecutivos (ROI, Punto de Equilibrio, etc)
kpis_ejecutivos = pd.read_csv(f"{BASE_PATH}\\financial_summary.csv")

# impacto mensual para graficas de tendencia financiera
dim_impacto_mensual = pd.read_csv(f"{BASE_PATH}\\monthly_impact.csv")

# top 50 alertas
top_alertas = fact_transacciones[fact_transacciones["alerta_activa"]==1]\
    .sort_values("risk_score_final", ascending=False)\
    .head(50)