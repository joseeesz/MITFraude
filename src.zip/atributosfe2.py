# atributos 2
# genera variables a nivel transaccion para el modelo ml
# incluye estadisticas historicas, ventanas de tiempo y riesgo geografico

import pandas as pd
import numpy as np
import os

# config
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
INPUT_TX = os.path.join(DATA_DIR, "transactions.csv")
INPUT_CLI = os.path.join(DATA_DIR, "clientes.csv")
OUTPUT = os.path.join(DATA_DIR, "transactions_features.csv")

# paises alto riesgo fatf
PAISES_RIESGOSOS = {
    "KY", "PA", "VG", "BZ", "LB", "IR", "KP", "MM", "SY",
    "YE", "AF", "HT", "LA", "UZ", "VU", "ZW"
}

def cargar_datos():
    df_tx = pd.read_csv(INPUT_TX, parse_dates=["fecha"])
    df_cli = pd.read_csv(INPUT_CLI)
    df = df_tx.merge(df_cli[["cliente_id", "pais_habitual", "antiguedad_dias",
                               "promedio_gasto", "saldo_promedio"]],
                     on="cliente_id", how="left")
    df = df.sort_values(["cliente_id", "fecha"]).reset_index(drop=True)
    return df

def feature_estadisticas_cliente(df: pd.DataFrame) -> pd.DataFrame:
    # features 1-3 promedios y desviaciones historicas sin data leakage
    promedios, desviaciones, ratios = [], [], []

    for idx, row in df.iterrows():
        historico = df[
            (df["cliente_id"] == row["cliente_id"]) &
            (df["fecha"] < row["fecha"])
        ]["monto"]

        if len(historico) >= 3:
            prom = historico.mean()
            std = historico.std()
        else:
            prom = row["promedio_gasto"]
            std = prom * 0.3

        std = max(std, 1.0)
        ratio = row["monto"] / prom if prom > 0 else 1.0

        promedios.append(round(prom, 2))
        desviaciones.append(round(std, 2))
        ratios.append(round(ratio, 4))

    df["promedio_gasto_cliente"] = promedios
    df["desviacion_gasto"] = desviaciones
    df["monto_vs_promedio"] = ratios
    return df

def feature_frecuencia_ventana(df: pd.DataFrame) -> pd.DataFrame:
    # features 4-5 conteos en ventanas de 24h y 1h
    freq_24h, freq_1h = [], []

    for idx, row in df.iterrows():
        base = df[df["cliente_id"] == row["cliente_id"]]
        f = row["fecha"]
        
        v24 = base[(base["fecha"] >= f - pd.Timedelta(hours=24)) & (base["fecha"] < f)]
        v1h = base[(base["fecha"] >= f - pd.Timedelta(hours=1)) & (base["fecha"] < f)]
        
        freq_24h.append(len(v24))
        freq_1h.append(len(v1h))

    df["frecuencia_tx_24h"] = freq_24h
    df["frecuencia_tx_1h"] = freq_1h
    return df

def feature_geografia(df: pd.DataFrame) -> pd.DataFrame:
    # features 6-7 riesgo por pais
    df["pais_riesgoso"] = df["pais_destino"].isin(PAISES_RIESGOSOS).astype(int)
    df["cambio_ubicacion"] = (df["pais_destino"] != df["pais_habitual"]).astype(int)
    return df

def feature_cliente_nuevo(df: pd.DataFrame) -> pd.DataFrame:
    # feature 8 antiguedad menor a 90 dias
    df["cliente_nuevo"] = (df["antiguedad_dias"] < 90).astype(int)
    return df

def feature_hora_inusual(df: pd.DataFrame) -> pd.DataFrame:
    # feature 9 horario de madrugada
    df["hora_inusual"] = df["fecha"].dt.hour.between(0, 4).astype(int)
    return df

def feature_smurfing(df: pd.DataFrame) -> pd.DataFrame:
    # feature 10 deteccion de fraccionamiento en ventana de 2h
    scores = []
    for idx, row in df.iterrows():
        base = df[df["cliente_id"] == row["cliente_id"]]
        f = row["fecha"]
        ventana = base[
            (base["fecha"] >= f - pd.Timedelta(hours=2)) &
            (base["fecha"] < f) &
            (base["monto"] >= 500) &
            (base["monto"] <= 3000)
        ]
        score = min(len(ventana), 10) / 10
        scores.append(round(score, 4))

    df["score_smurfing"] = scores
    return df

def calcular_risk_score(df: pd.DataFrame) -> pd.DataFrame:
    # calculo de score heuristico ponderado
    m_norm = (df["monto_vs_promedio"].clip(0, 5) / 5)
    f1h_norm = (df["frecuencia_tx_1h"].clip(0, 5) / 5)
    geo_score = (df["pais_riesgoso"] * (1 + m_norm * 0.5)).clip(0, 1)

    score = (
        m_norm * 0.35 +
        f1h_norm * 0.25 +
        df["score_smurfing"] * 0.18 +
        geo_score * 0.15 +
        df["cambio_ubicacion"] * 0.04 +
        df["hora_inusual"] * 0.02 +
        df["cliente_nuevo"] * 0.01
    )

    df["risk_score"] = score.round(4)
    df["nivel_riesgo"] = pd.cut(df["risk_score"], bins=[-0.001, 0.30, 0.70, 1.01], labels=["BAJO", "MEDIO", "ALTO"])
    
    # flags de reglas
    df["flag_monto_inusual"] = (df["monto_vs_promedio"] > 3).astype(int)
    df["flag_frecuencia_anormal"] = (df["frecuencia_tx_1h"] >= 5).astype(int)
    df["flag_pais_riesgoso"] = df["pais_riesgoso"]
    df["flag_smurfing"] = (df["score_smurfing"] >= 0.5).astype(int)
    return df

def run_pipeline():
    df = cargar_datos()
    df = feature_estadisticas_cliente(df)
    df = feature_frecuencia_ventana(df)
    df = feature_geografia(df)
    df = feature_cliente_nuevo(df)
    df = feature_hora_inusual(df)
    df = feature_smurfing(df)
    df = calcular_risk_score(df)

    cols = [
        "transaction_id", "cliente_id", "fecha", "monto", "tipo_tx",
        "pais_origen", "pais_destino", "canal", "saldo_post",
        "promedio_gasto_cliente", "desviacion_gasto", "monto_vs_promedio",
        "frecuencia_tx_24h", "frecuencia_tx_1h", "pais_riesgoso",
        "cambio_ubicacion", "cliente_nuevo", "hora_inusual", "score_smurfing",
        "risk_score", "nivel_riesgo", "flag_monto_inusual",
        "flag_frecuencia_anormal", "flag_pais_riesgoso", "flag_smurfing",
        "fraude", "patron_fraude"
    ]
    df[cols].to_csv(OUTPUT, index=False)
    print(f"proceso terminado: {OUTPUT}")

if __name__ == "__main__":
    run_pipeline()